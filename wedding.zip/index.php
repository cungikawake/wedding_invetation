<?php 
    if(isset( $_GET['tamu'] )){
        $tamu =  $_GET['tamu'];
    }else{
        $tamu = '';
    }
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dewa Hery & Dewa Ayu, Jumat 20 Oktober 2023 | Genta Mas Bali</title>
    <meta name="description" content="Dengan segala kerendahan hati dan dengan ungkapan syukur atas karunia Tuhan, Kami mengundang Bapak/Ibu/Saudara(i) untuk menghadiri Acara Lamaran dan Resepsi Pernikahan kami">
    
     <meta property="og:title" content="Dewa Hery & Dewa Ayu, Jumat 20 Oktober 2023 | Genta Mas Bali">
    <meta property="og:type" content="website"> 
    <meta property="og:url" content="https://dewahery-dewaayu.gentamasbali.com/">
    <meta property="og:image" content="https://dewahery-dewaayu.gentamasbali.com/aset/1.jpg">
    <meta property="og:description" content="Dengan segala kerendahan hati dan dengan ungkapan syukur atas karunia Tuhan, Kami mengundang Bapak/Ibu/Saudara(i) untuk menghadiri Acara Lamaran dan Resepsi Pernikahan kami">
    <meta property="fb:app_id" content="123456789">
    
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.0.2/css/bootstrap.min.css"   crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- Custom CSS -->
    <link rel="stylesheet" href="css/style.css">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Great+Vibes&display=swap&family=Montserrat:wght@400;700" rel="stylesheet">

    <style>
        body {
          max-width:50%;
          justify-content: center;
          align-items: center;
          margin:0 auto;
        }
         
        #header{  
            min-height:320px; 
        }
        .judul{
            font-size:50px;
        }
        .slider1{
            display: flex; /* sets the container to a flex container */
              justify-content: center; /* centers the contents horizontally */
              align-items: center; /* centers the contents vertically */
        }
        .slider1 img{
            width:100%;
        }
        .countdown {
			display: flex;
			flex-wrap: wrap;
			justify-content: center;
			align-items: center;
			text-align: center;
			font-size: 12px;
			font-weight: bold;
			color: #fff;
		}
		
		.countdown span {
			display: block;
			margin: 0 1rem;
			background-color: #d0a888;
			padding: 0.5rem;
			border-radius: 5px;
			box-shadow: 0 0 10px rgba(0,0,0,0.2);
		}
		
		.countdown span:nth-child(1) {
			background-color: #d0a888;
			color: #fff;
		}
		.ornamen1{
		    max-width:150px; 
		    padding-top:100px;
		    padding-bottom: 15px;
		}
		
    
        #mempelai{ 
            min-height:400px;
        }
        #weda{
            min-height:700px;
            background:url('aset/doa.jpg');
            background-size: cover;
            width:100%;
            background-position: top center;
             
        }
        #isiweda{
            border-style: double;
            border-width: 10px 10px 10px 10px;
            border-color: #E8D3C3;
            padding:10%;
            margin: 20px 20px 20px 20px;
            padding: 40px 20px 40px 20px;
        }
        
        #slider {
          position: relative;
          width: 100%;
          min-height:320px; 
          overflow: hidden;
        }
        
         

        
        @media only screen and (max-width: 768px) {
            body{
                max-width:100%;
            }
			.countdown {
				font-size: 12px;
			}
			.judul{
                font-size:30px;
            }
			.countdown span {
				padding: 0.25rem;
			}
			.ornamen1{
    		    max-width:150px; 
    		    padding-top:50px;
    		}
    		#weda{
                min-height:700px;
                background:url('aset/doa.jpg');
                background-size: cover;
                width:100%;  
            }
		}
		
		.gallery_container{
    display: grid;
    grid-template-columns: repeat(8,1fr);
    grid-template-rows: repeat(8,5vw);
    grid-gap: 1rem;
    padding: 1rem;
}
 
.gallery_container .gallery_item{
    cursor: pointer;
    position: relative;
    overflow: hidden;
}
 
.gallery_container .gallery_item img{
    width: 100%;
    height: 100%;
    object-fit: cover;
    transition: .3s;
}
 
.gallery_container .gallery_item figcaption{
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    color: #fff;
    font-weight: bold;
    opacity: 0;
    transition: .3s;
    text-align: center;
}
 
 
.gallery_container .gallery_item:hover img{
    filter: brightness(.5);
    transform: scale(1.2);
}
 
.gallery_container .gallery_item:hover figcaption{
    opacity: 1;
}
 
.gallery_container .gallery_item.item_1{
    grid-column-start: 1;
    grid-column-end: 3;
    grid-row-start: 1;
    grid-row-end: 5;
}
 
.gallery_container .gallery_item.item_2{
    grid-column-start: 3;
    grid-column-end: 5;
    grid-row-start: 1;
    grid-row-end: 5;
}
 
.gallery_container .gallery_item.item_3{
    grid-column-start: 5;
    grid-column-end: 9;
    grid-row-start: 1;
    grid-row-end: 7;
}
 
.gallery_container .gallery_item.item_4{
    grid-column-start: 1;
    grid-column-end: 5;
    grid-row-start: 5;
    grid-row-end: 9;
}
.gallery_container .gallery_item.item_5{
    grid-column-start: 1;
    grid-column-end: 5;
    grid-row-start: 9;
    grid-row-end: 12;
}
.gallery_container .gallery_item.item_6{
    grid-column-start: 5;
    grid-column-end: 9;
    grid-row-start: 7;
    grid-row-end: 11;
}
.gallery_container .gallery_item.item_7{
    grid-column-start: 5;
    grid-column-end: 9;
    grid-row-start: 11;
    grid-row-end: 11;
}
 
@media (max-width: 600px) {
    .gallery_container{
        grid-gap: .5em;
    }
 
    .gallery_container .gallery_item figcaption{
        font-size: .8rem;
    }
 
    .gallery_container .gallery_item.item_1{
        grid-column-start: 1;
        grid-column-end: 5;
        grid-row-start: 1;
        grid-row-end: 5;
    }
     
    .gallery_container .gallery_item.item_2{
        grid-column-start: 5;
        grid-column-end: 10;
        grid-row-start: 1;
        grid-row-end: 5;
    }
     
    .gallery_container .gallery_item.item_3{
        grid-column-start: 5;
        grid-column-end: 10;
        grid-row-start: 5;
        grid-row-end: 11;
    }
     
    .gallery_container .gallery_item.item_4{
        grid-column-start: 1;
        grid-column-end: 5;
        grid-row-start: 5;
        grid-row-end: 9;
    }
    .gallery_container .gallery_item.item_5{
        grid-column-start: 1;
        grid-column-end: 5;
        grid-row-start: 9;
        grid-row-end: 14;
    }
    .gallery_container .gallery_item.item_6{
        grid-column-start: 5;
        grid-column-end: 10;
        grid-row-start: 11;
        grid-row-end: 12;
    }
    .gallery_container .gallery_item.item_7{
        grid-column-start: 5;
        grid-column-end: 10;
        grid-row-start: 12;
        grid-row-end: 14;
    }
 
}
 
@media (max-width: 423px){
    .gallery_container{
        display: flex;
        flex-direction: column;
    }
}
 
.lightbox_container{
    width: 100%;
    height: 100vh;
    background-color: #000000c0;
    position: fixed;
    z-index: 0;
    top: 0;
    left: 0;
    display: flex;
    justify-content: center;
    align-items: center;
    overflow: hidden;
    transform: scale(.5);
    opacity: 0%;
    visibility: hidden;
    transition: .3s;
}
 
.lightbox_container.show{
    transform: scale(1);
    opacity: 100%;
    visibility: visible;
}
 
.lightbox_container #close{
    color: #fff;
    z-index: 3;
    position: absolute;
    top: 2rem;
    right: 2rem;
    padding: .25em .4em;
    border-radius: 50%;
    transform: scale(1.7);
    cursor: pointer;
    transition: .3s;
}
 
.lightbox_container #close:hover{
    background-color: #dfdfdf6c;
}
 
.lightbox_container #close:active{
    background-color: rgb(0, 0, 0);
    transition: 0s !important;
}
 
.lightbox_container .parent_navigation{
    position: static;
    z-index: 3;
    width: 100%;
    height: auto;
    display: flex;
    align-items: center;
    justify-content: space-between;
}
 
.lightbox_container .parent_navigation #ripple{
    font-size: 1.6rem;
    color: #fff;
    padding: .8em;
    margin: 4rem;
    cursor: pointer;
    position: relative;
    overflow: hidden;
    transition: .3s;
}
 
.lightbox_container .parent_navigation #ripple:hover{
    background-color: #dfdfdf6c;
}
 
.lightbox_container .parent_navigation #ripple span{
    position: absolute;
    background-color: #dfdfdf6c;
    pointer-events: none;
    transform: translate(-50%, -50%);
    animation: anim 1s;
    border-radius: 50%;
}
 
@keyframes anim {
    0%{
        height: 0px;
        width: 0px;
        opacity: 100%;
    }
    100%{
        height: 500px;
        width: 500px;
        opacity: 0%;
    }
}
 
.lightbox_container .lightbox_item{
    position: absolute;
    height: auto;
    width: 70%;
    transition: .3s ease-in;
}
 
.lightbox_container .lightbox_item.active{
    opacity: 0;
}
 
.lightbox_container .lightbox_item img{
    width: 100%;
    height: 100%;
    object-fit: cover;
}
 
.lightbox_container .lightbox_item figcaption{
    text-align: center;
    color: #fff;
    font-weight: bold;
    font-size: 1.4rem;
    padding-top: .5rem;
}
 
@media (max-width: 700px){
    .lightbox_container .lightbox_item{
        width: 83%;
    }
    .lightbox_container .parent_navigation #ripple{
        margin: 0rem;
        padding: .4em;
    }
}
    </style>
    <style>
		.modal {
			display: none;
			position: fixed;
			z-index: 1;
			left: 0;
			top: 0;
			width: 100%;
			height: 100%;
			overflow: auto;
			background-color: rgba(0,0,0,0.4);
		}
		.modal-content {
			background-color: white;
			margin: 15% auto;
			padding: 20px;
			border: 1px solid #888;
			width: 80%;
			max-width: 600px;
			text-align: center;
			position: relative;
		}
		.close {
			position: absolute;
			top: 5px;
			right: 10px;
			font-size: 28px;
			font-weight: bold;
			color: #aaa;
			cursor: pointer;
		}
	</style>
  </head>
  <body style="background:#1f2023;"> 
    <!-- Main Content -->
    <section>
        <div id="myModal" class="modal">
    		<div class="modal-content">
    			<span class="close">&times;</span>
    			<h2 style="color: #d0a988;font-family:'Great Vibes', Sans-serif;" class="judul">Dewa Hery & Dewa Ayu</h2>
    			<p>Kepada Bpk/Ibu/Saudara/i</p>
    			<h4><?php echo $tamu; ?></h4>
    			<p>Tanpa mengurangi rasa hormat, kami mengundang anda untuk hadir di acara lamaran dan pernikahan kami.</p>
    			<button style="fill: #54595F;
    color: #54595F;
    font-family: 'Combo', Sans-serif;
    font-size: 18px;
    background-color: #E8D3C3;
    border-radius: 8px 8px 8px 8px;" id="buka">Buka Undangan</button>
    		</div>
    	</div>   
    </section>
    
    <section style="margin-bottom:10px;">
        
        <div class="container" id="header">
            <div  class="slider1">
                <img src="aset/1.jpg">
                <h2 style="position:absolute;top:10px;color: #210b2e;font-family:'Great Vibes', Sans-serif;text-align:center;left:20px;" class="judul">Dewa Hery <br>&<br> Dewa Ayu</h2>
            </div>
            
            <div class="row" style="margin-top:-10px;">
                <div class="col-md-12 text-center">   
                  <h4 style="color: #d0a988; font-size:16px;margin-top:15px;">We invited you to celebrate our wedding</h4>
                  <h4 style="color: #d0a988;font-size:20px;">Jumat 20 Oktober 2023</h4> 
                </div> 
                <div class="col-md-12">
                    <div class="countdown">
                		<span id="days">00</span>
                		<span id="hours">00</span>
                		<span id="minutes">00</span>
                		<span id="seconds">00</span>
                	</div>
                </div>
          </div> 
        </div>
    </section>
    
    <section>
        <div class="container" id="mempelai"> 
            <div class="row">
                <div class="col-md-12 text-center">
                    <img class="ornamen1" src="driver1.png" style="margin: 0;">
                    
                    <h3 style="font-size: 40px;color:#d0a988;font-family:'Great Vibes', Sans-serif;">Om Swastyastu</h3>
                    <p style="font-size: 16px;color:#d0a988;font-family: 'Montserrat', Sans-serif;">Dengan segala kerendahan hati dan dengan ungkapan syukur atas karunia Tuhan, Kami mengundang Bapak/Ibu/Saudara(i) untuk menghadiri Acara Lamaran dan Resepsi Pernikahan kami :</p>
                </div>
                <div class="col-md-6 text-center">
                    <div>
                        <img src="aset/cowok.jpg" style="max-width:300px;">
                    </div>
                    <h1 style="font-size: 40px;color:#d0a988;font-family:'Great Vibes', Sans-serif;">I Dewa Putu Hery Priyana, S.AP</h1>
                    <!--<p style="font-size: 16px;color:#d0a988;font-family: 'Montserrat', Sans-serif;">Putra pertama dari pasangan </p>-->
                    <h4 style="margin-top: -15px;font-size: 16px;color:#d0a988;font-family: 'Montserrat', Sans-serif;">I Dewa Putu Putra (Alm) & I Dewa Ayu Raka (Alm)</h4>
                    <p style="margin-top: -15px;font-size: 16px;color:#d0a988;font-family: 'Montserrat', Sans-serif;">Br. Gunung, Des.Abiansemal, Kec.Abiansemal, Kab.Badung </p>
                </div>
                <div class="col-md-6 text-center">
                    <div>
                        <img src="aset/cewekk.jpg" style="max-width:300px;">
                    </div>
                    <h1 style="font-size: 40px;color:#d0a988;font-family:'Great Vibes', Sans-serif;">I Dewa Ayu Mariani</h1>
                    <!--<p style="font-size: 16px;color:#d0a988;font-family: 'Montserrat', Sans-serif;">Putri ke dua dari pasangan </p>-->
                    <h4 style="margin-top: -15px;font-size: 16px;color:#d0a988;font-family: 'Montserrat', Sans-serif;">I Dewa Gede Putra & I Dewa Ayu Rai</h4>
                    <p style="margin-top: -15px;font-size: 16px;color:#d0a988;font-family: 'Montserrat', Sans-serif;">Br.Tengah, Des.Sidemen, Kec.Sidemen, Kab.Karangasem</p>
                </div>
                <div class="col-12 text-center">
                     <img class="ornamen1" src="driver3.png" style="margin: 0;padding-top:10px;">
                </div>
            </div>
        </div> 
    </section>
    
    <section id="weda">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div id="isiweda" style="background:#0201019C;">
                        <p style="font-size: 16px;color:#d0a988;font-family: 'Montserrat', Sans-serif;">Grbhnāmi te saubhagatvāya hastam, Mayā patyā jaradastir yathāsah, Bhago aryamā savitā puramdhir, Mahyam tvādurgārhapatyāya devāh.</p>
                        <p style="font-size: 16px;color:#d0a988;font-family: 'Montserrat', Sans-serif;"> 
                            Dalam sebuah pernikahan kalian disatukan demi sebuah kebahagiaan dengan janji hati untuk saling membahagiakan. Bersamaku engkau akan hidup selamanya karena Tuhan pasti akan memberikan karunia sebagai pelindung dan saksi dalam pernikahan ini. Untuk itulah kalian dipersatukan dalam satu keluarga.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <section>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <img class="ornamen1" src="Ornamen_003.png" style="margin: 0;padding-top:10px;position: absolute;margin-top: -15px;right:0;">
                    
                    <h3 class="text-center" style="font-size: 40px;color:#d0a988;font-family:'Great Vibes', Sans-serif;margin-top:75px;" >Save The Date</h3>
                    <p style="text-align:center;font-size: 16px;color:#d0a988;ont-family: 'Montserrat', Sans-serif;">Merupakan suatu kehormatan dan kebahagiaan bagi kami apabila Bapak/Ibu/Saudara/I berkenan hadir untuk memberikan doa restu kepada kedua mempelai</p>
                    <div class="col-12 text-center">
                     <img class="ornamen1" src="driver3.png" style="margin: 0;padding-top:10px;">
                    </div>
                    <div class="col-12 text-center">
                        <div class="card">
                            <div class="card-body text-center">
                                <h3 class="text-center" style="font-size: 40px;color:#d0a988;font-family:'Great Vibes', Sans-serif;margin-top:75px;" >Acara Resepsi</h3>
                                <p style="text-align:center;font-size: 16px;color:#d0a988;font-family: 'Montserrat', Sans-serif;">Jumat 20 Oktober 2023</p>
                                <p style="margin-top:-15px;text-align:center;font-size: 16px;color:#d0a988;font-family: 'Montserrat', Sans-serif;">11:00 AM - selesai </p>
                                <p style="margin-top:-15px;text-align:center;font-size: 16px;color:#d0a988;font-family: 'Montserrat', Sans-serif;">Br. Gunung, Des.Abiansemal, Kec.Abiansemal, Kab.Badung</p>
                                <a href="https://goo.gl/maps/qy1q8cUckfaYm9bk9" target="_blank">
                                    <button style="font-family: 'Caveat', Sans-serif;color:#fff;
                                        font-size: 18px;
                                        background-color: #424242;
                                        border-style: solid;
                                        border-radius: 8px 8px 8px 8px;
                                        padding: 5px 5px 5px 5px;">Buka Google Map</button>
                                    
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="col-12">
                     <img class="ornamen1" src="Ornamen_004.png" style="margin: 0;padding-top:10px;left:0;bottom:0;position:relative;margin-top:-475px;">
                    </div>
                    
                </div>
            </div>
        </div>
    </section>
    
    <section>
        <div id="slider">
            <!-- Ini Gallery -->
            <div class="gallery_container_parent">
                <div class="gallery_container">
                    
             
                    <figure class="gallery_item item_7" onclick="openmodal();currentslide(7)" style="padding: 20px;
    border: 2px solid #d0a988;
    border-radius: 20px;">
                        <img src="aset/1.jpg" alt="truck_image">
                        <figcaption class="caption"> <br><br>  <br> <i class="fas fa-search"></i> </figcaption>
                    </figure>
                    
                    <figure class="gallery_item item_1" onclick="openmodal();currentslide(1)" style="padding: 20px;
    border: 2px solid #d0a988;
    border-radius: 20px;">
                        <img src="aset/22.jpg" alt="bike_image">
                        <figcaption class="caption"><br><br>   <br> <i class="fas fa-search"></i> </figcaption>
                    </figure>
             
                    <figure class="gallery_item item_2" onclick="openmodal();currentslide(2)" style="padding: 20px;
    border: 2px solid #d0a988;
    border-radius: 20px;">
                        <img src="aset/33.jpg" alt="phone_image">
                        <figcaption class="caption"><br><br>  <br> <i class="fas fa-search"></i> </figcaption>
                    </figure> 
             
                    <figure class="gallery_item item_4" onclick="openmodal();currentslide(4)" style="padding: 20px;
    border: 2px solid #d0a988;
    border-radius: 20px;">
                        <img src="aset/44.jpg" alt="truck_image">
                        <figcaption class="caption"> <br><br> <br> <i class="fas fa-search"></i> </figcaption>
                    </figure>
             
                    <figure class="gallery_item item_5" onclick="openmodal();currentslide(5)" style="padding: 20px;
    border: 2px solid #d0a988;
    border-radius: 20px;">
                        <img src="aset/55.jpg" alt="bike_image">
                        <figcaption class="caption"> <br><br>  <br> <i class="fas fa-search"></i> </figcaption>
                    </figure>
             
                    <figure class="gallery_item item_6" onclick="openmodal();currentslide(6)" style="padding: 20px;
    border: 2px solid #d0a988;
    border-radius: 20px;">
                        <img src="aset/66.jpg" alt="phome_image">
                        <figcaption class="caption"><br><br> <br> <i class="fas fa-search"></i> </figcaption>
                    </figure>
                    <figure class="gallery_item item_6" onclick="openmodal();currentslide(6)" style="padding: 20px;
    border: 2px solid #d0a988;
    border-radius: 20px;">
                        <img src="aset/77.jpg" alt="phome_image">
                        <figcaption class="caption"><br><br> <br> <i class="fas fa-search"></i> </figcaption>
                    </figure>
                </div>
            </div>
             
              
        </div>
    </section>
    
    <section id="weda" style="background:#0201019C;">
        <div class="container">
            <p style="text-align:center;font-size: 16px;color:#d0a988;font-family: 'Montserrat', Sans-serif;">Jangan ragu untuk datang, kami sudah berkoordinasi dengan semua pihak terkait pencegahan penularan COVID-19. Acara kami akan mengikuti segala prosedur protokol kesehatan untuk mencegah penularan COVID-19.</p>
            <div class="row">
                <div class="col-md-12 text-center">
                    <img src="https://contoh2.gentamasbali.com/images/masker.png" style="max-width: 100px;">
                    <img src="https://contoh2.gentamasbali.com/images/cuci-tangan.png" style="max-width: 100px;">
                    <img src="https://contoh2.gentamasbali.com/images/jaga-jarak.png" style="max-width: 100px;">
                    
                    <p style="text-align:center;font-size: 16px;color:#d0a988;font-family: 'Montserrat', Sans-serif;">
                        Bagi para tamu undangan diharapkan mengikuti protokol pencegahan COVID-19.
                    </p>
                </div> 
                <div class="col-12 text-center">
                    <img class="ornamen1" src="driver1.png" style="margin: 0;">
                </div>
                  
            </div>
            
            <div class="row"> 
                <div class="col-md-12 text-center">
                    <div>
                        <img src="aset/doa.jpg" style="max-width:300px;">
                    </div>
                    <h2 style="color: #d0a988;font-family:'Great Vibes', Sans-serif;" class="judul">Dewa Hery & Dewa Ayu</h2>
                    <h4 style="color: #d0a988; font-size:16px;margin-top:15px;">Atas kehadiran dan doa restunya, kami ucapkan terimakasih.</h4>
                    <h4 style="color: #d0a988;font-family:'Great Vibes', Sans-serif;" class="judul">Om Shanti Shanti Shanti Om</h2>
                </div>
            </div>
        </div>
    </section>
    <!-- Footer -->
    <footer class="bg-dark text-white text-center">
        
       <audio id="player" style="display:none;">
          <source src='aset/mymusik.mp3' type='audio/mpeg'/>
        </audio> 
    </footer>
    <!-- Bootstrap JavaScript -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.0.2/js/bootstrap.min.js"   crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <!-- Parallax JavaScript -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"   crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jarallax/1.12.7/jarallax.min.js" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
     
    <script>
		// Set the date we're counting down to
		var countDownDate = new Date("Oct 20, 2023 20:00:00").getTime();

		// Update the countdown every 1 second
		var x = setInterval(function() {

			// Get today's date and time
			var now = new Date().getTime();

			// Find the distance between now and the count down date
			var distance = countDownDate - now;

			// Time calculations for days, hours, minutes and seconds
			var days = Math.floor(distance / (1000 * 60 * 60 * 24));
			var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
			var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
			var seconds = Math.floor((distance % (1000 * 60)) / 1000);

			// Display the result in the element with id="countdown"
			document.getElementById("days").innerHTML = days + "Hari";
			document.getElementById("hours").innerHTML = hours + "Jam";
			document.getElementById("minutes").innerHTML = minutes + "Menit";
			document.getElementById("seconds").innerHTML = seconds + "Detik";

			// If the count down is finished, write some text
			if (distance < 0) {
				clearInterval(x);
				document.getElementById("countdown").innerHTML = "EXPIRED";
			}
		}, 1000);
		
		const lightbox = document.querySelector('.lightbox_container');
        const btn = document.querySelectorAll('#ripple');
        const next = document.querySelector('.next');
        const prev = document.querySelector('.prev');
        const close = document.getElementById('close');
         
        for (let i = 0; i < btn.length; i++){
            btn[i].addEventListener('click', (e)=>{
                let x = e.clientX - e.target.offsetLeft;
                let y = e.clientY - e.target.offsetTop;
         
                let ripple = document.createElement('span');
                ripple.style.left = `${x}px`;
                ripple.style.top = `${y}px`;
         
                btn[i].appendChild(ripple);
         
                setTimeout(() => {
                    ripple.remove();
                }, 700);
            });
        };
         
         
        function openmodal(){
            //lightbox.classList.add('show');
        }
         
        close.addEventListener('click', ()=>{
            lightbox.classList.remove('show');
        });
         
        prev.addEventListener('click', ()=>{
            plusslide(-1);
        });
         
        next.addEventListener('click', ()=>{
            plusslide(1);
        });
         
        let slideindex = 1;
        showslide(n);
         
        function plusslide(n){
            showslide(slideindex += n);
        };
         
        function currentslide(n){
            showslide(slideindex  = n);
        };
         
        function showslide(n){
            const slide = document.querySelectorAll('.lightbox_item');
             
            if(n > slide.length){
                slideindex=1;
            }
             
            if(n < 1){
                slideindex = slide.length;
            }
         
            for (let i = 0; i < slide.length; i++){
                slide[i].classList.add('active');
            }
            slide[slideindex-1].classList.remove('active');
        }

	</script>
	<script>
		$(document).ready(function(){
			setTimeout(function(){
				$('#myModal').show();
				$('#slider').focus();
			}, 1000); // delay in milliseconds
			
			$('#buka').click(function(){
			    $('#myModal').hide();
			});
		});
	</script>
	<script>
        var audio = document.getElementById("player");
        
        function myFunction() {
          audio.play();
        }
        
        $('#buka').on('click', function(){
            audio.play();
             
        });
        
        $(window).on('load', function(){
            //$('#play').click();
        });
        
    </script>
  </body>
</html>